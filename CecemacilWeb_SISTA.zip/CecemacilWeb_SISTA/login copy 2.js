//Membuat validasi terhadap form login dan register

function validasi_input(form) {

    if (form.username.value == "") {
        sweetAlert("Username masih kosong!");
        form.username.focus();
        return (false);
    }

    pola_username = /^[a-zA-Z0-9\_\-]{9,100}$/;
    if (!pola_username.test(form.username.value)) {
        sweetAlert('Username minimal 9 karakter saja');
        form.username.focus();
        return false;
    }

    if (form.password.value == "") {
        sweetAlert("Password masih kosong!");
        form.password.focus();
        return (false);
    }

    if (form.ulangi_password.value == "") {
        sweetAlert("Konfirmasi Password masih kosong");
        form.ulangi_password.focus();
        return (false);
    }

    return (true);
}

function checkPass() {
    var pass1 = document.getElementById('pass1');
    var pass2 = document.getElementById('pass2');
    var message = document.getElementById('confirmMessage');
    var goodColor = "#66cc66";
    var badColor = "#ff6666";

    if (pass1.value == pass2.value) {
        pass2.style.backgroundColor = goodColor;
        message.style.color = goodColor;
        message.innerHTML = "Password cocok"
    } else {
        pass2.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = "Password tidak cocok";
    }
}
var attempt = 3; // Variable to count number of attempts.
// Below function Executes on click of login button.
function daftar() {
    alert("Login Anda Berhasil");
    window.open("file:///D:/xampp/htdocs/tugas%20kelompok/berhasil.html")
    window.location = "success.html"; // Redirecting to other page.
    return false;
}